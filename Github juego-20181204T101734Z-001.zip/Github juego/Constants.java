package puch;
public class Constants {
	final int DIR_N = 0;
	 final int DIR_NNE = 1;
	 final int DIR_NE = 2;
	 final int DIR_ENE = 3;
	 final int DIR_E = 4;
	 final int DIR_ESE = 5;
	 final int DIR_SE = 6;
	 final int DIR_SSE = 7;
	 final int DIR_S = 8;
	 final int DIR_SSW = 9;
	 final int DIR_SW = 10;
	 final int DIR_WSW = 11;
	 final int DIR_W = 12;
	 final int DIR_WNW = 13;
	 final int DIR_NW = 14;
	 final int DIR_NNW = 15;
	 
	 public static final int[][] MOVES = {
			 { 0, -4 }, // DIR_N
			 { 1, -4 }, // DIR_NNE
			 { 3, -3 }, // DIR_NE
			 { 4, -1 }, // DIR_ENE
			 { 4, 0 }, // DIR_E
			 { 4, 1 }, // DIR_ESE
			 { 3, 3 }, // DIR_SE
			 { 1, 4 }, // DIR_SSE
			 { 0, 4 }, // DIR_S
			 { -1, 4 }, // DIR_SSW
			 { -3, 3 }, // DIR_SW
			 { -4, 1 }, // DIR_WSW
			 { -4, 0 }, // DIR_W
			 { -4,-1 }, // DIR_WNW
			 { -3,-3 }, // DIR_NW
			 { -1,-4 }, // DIR_NNW
	 };
	 
	 public static String [][] IMAGES = {
			 { "enemy100.png","enemy109.png", "enemy110.png", "enemy111.png", "enemy112.png","enemy113.png", "enemy114.png","enemy115.png","enemy108.png",
				 "enemy101.png","enemy102.png", "enemy103.png","enemy105.png","enemy103.png","enemy106.png", "enemy107.png" },
			 { "enemy200","enemy201", "enemy202", "enemy203", "enemy204","enemy205", "enemy206","enemy207","enemy208",
				 "enemy209","enemy210", "enemy211","enemy212","enemy213","enemy214", "enemy215", },
			 { "enemy300","enemy301", "enemy302", "enemy303", "enemy304","enemy305", "enemy306","enemy307","enemy308",
					 "enemy309","enemy310", "enemy311","enemy312","enemy313","enemy314", "enemy315" },
			 { "enemy900","enemy901", "enemy902", "enemy903", "enemy904","enemy905", "enemy906","enemy907","enemy908",
						 "enemy909","enemy910", "enemy911","enemy912","enemy913","enemy914", "enemy915" },
		};

}
