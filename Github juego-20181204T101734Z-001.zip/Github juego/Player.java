package puch;
public class Player {
	private int x = 85;
	private int y = 200;
	private int points;
	private int fireR = 1;
	private int health = 3;
	private int shots;
	private int hits;
	private int id = 0;
	private String image = "player.png";
	private boolean alive = true;
	
	
	public void setX(int x) {
		if (x>5 && x<165) {
			this.x = x;
		}
		
	}
	
	public void setY(int x) {
		if (x>0 && x<170) {
			this.y = x;
		}
		
	}
	
	public void setPoints(int points) {
		this.points = points;
	}
	
	public void setHealth(int health) {
		this.health = health;
	}
	
	public void setShots(int shots) {
		this.shots = shots;
	}
	
	public void setHits(int hits) {
		this.hits = hits;
	}
	
	public int getX() {
		return this.x;
	}
	
	public int getY() {
		return this.y;
	}
	
	public int getPoints() {
		return this.points;
	}

	public int getFireR() {
		return this.fireR;
	}

	public int getHealth() {
		return this.health;
	}
	
	public int getShots() {
		return this.shots;
	}
	
	public int getHits() {
		return this.hits;
	}
	
	public int getId() {
		return this.id;
	}
	
	public String getImage() {
		return this.image;
	}
	
	
	
}
