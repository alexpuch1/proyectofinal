package puch;
public class Enemy {
	private int x;
	private int y;
	private String images;
	private int id;
	private int direction [] = new int[2];
	private int type;
	
	public Enemy(int x, int y, String images, int id) {
		
		setX(x);
		setY(y);
		setImages0(images);
		setId(id);
		//move(dir[][], aDir[][]);
		
		
	}
	
	
	
	public void setX(int x) {
		this.x = x;
	}
	
	public void setY(int y) {
		this.y = y;
	}
	
	public void setImages0(String images) {
		this.images = images;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	
	public int getX() {
		return this.x;
	}
	
	public int getY() {
		return this.y;
	}
	
	public String getImages() {
		return this.images;
	}
	
	public int getId() {
		return this.id;
	}
	
	public int getPosX() {
		return this.direction[0];
	}
	
	public int getPosY() {
		return this.direction[1];
	}
	
	public void setImage(int dir){
		
	}
	
	
	
	
	public void move(int dir, int steps) {
		
		int x = getX();
		int y = getY();
		
		x = x + steps * Constants.MOVES [dir][0];
		y = y + steps * Constants.MOVES [dir][1];
		
		setX(x);
		setY(y);
		
		
		this.direction[0] = Constants.MOVES [dir][0];
		this.direction[1] = Constants.MOVES [dir][1];	
		
		setImage(dir);
	}
	
	public int[] getDir() {
		int [] dir = new int [2];
		dir[0] = this.direction[0];
		dir[1] = this.direction[1];
		return dir;
	}
	
	public int getCard() {
		int [] dir = { getDir()[0], getDir()[1]};
		int x = 0;
		if (dir[0] == 0 && dir[1] == -4) {
			x = 8;
		}
		if (dir[0] == 1) {
			if(dir[1] == -4) { x = 1;}
			else if (dir[1] == 4) { x=7;}
		}
		else if (dir[0] == -1) {
			if(dir[1] == -4) { x = 15;}
			else if (dir[1] == 4) { x=9;}
		}
		else if (dir[0] == 3) {
			if(dir[1] == -3) { x = 2;}
			else if (dir[1] == 3) { x=6;}
		}
		else if (dir[0] == -3) {
			if(dir[1] == -3) { x = 14;}
			else if (dir[1] == 3) { x=10;}
		}
		else if (dir[0] == 4) {
			if(dir[1] == 0) { x = 4;}
			else if (dir[1] == 1) { x=5;}
			else if (dir[1] == -1) { x=3;}
		}
		else if (dir[0] == -4) {
			if(dir[1] == 0) { x = 12;}
			else if (dir[1] == 1) { x = 11;}
			else if (dir[1] == -1) { x= 13;}
		}
		
		return x;
	}
	public void setImagesM() {
		this.images = Constants.IMAGES [0][getCard()];
	}
	public void Mcu(int times, int radius)
	{
		for (int i = 0 ; i < times ; i++)
		{
			move(0,radius);
			move(1,radius);
			move(2,radius);
			move(3,radius);
			move(4,radius);
			move(5,radius);
			move(6,radius);
			move(7,radius);
			move(8,radius);
			move(9,radius);
			move(10,radius);
			move(11,radius);
			move(12,radius);
			move(13,radius);
			move(14,radius);
			move(15,radius);
		}
	}
	

}

