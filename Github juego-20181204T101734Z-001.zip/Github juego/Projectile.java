package puch;
public class Projectile {
	private boolean ally = true;
	private int xpos;
	private int ypos;
	private String image;
	private int id;
	
	
	public Projectile(int x, int y,int id, boolean t) {
		this.xpos =x;
		this.ypos = y;
		this.ally = t;
		if (t == true) {
			this.image = "torpedo100.png";
		}
		else {
			this.image = "torpedo200.png";
		}
		this.id = id;
		
	}
	
	public boolean getAlly() 
	{
		return ally;
	}
	public void setAlly(boolean ally) 
	{
		this.ally = ally;
	}
	public int getXpos() 
	{
		return xpos;
	}
	public void setXpos(int xpos) 
	{
		this.xpos = xpos;
	}
	public int getYpos() 
	{
		return ypos;
	}
	public void setYpos(int ypos)
	{
		this.ypos = ypos;
	}
	public String getImage()
	{
		return image;
	}
	public void setImage(String image)
	{
		this.image = image;
	}
	public int getId() 
	{
		return id;
	}
	public void setID(int Id) 
	{
		this.id = Id;
		
	}
	
	
	
	
}
