package puch;

public class Swarm 
{
	private Enemy[] enemies;
	private int nenemies;
	private String shape;
	
	public Enemy[] getEnemies() {
		return enemies;
	}
	Swarm(int n)
	{
		setEnemies(n);
	}
	public void setEnemies(int n) {
		this.nenemies = n;
		int x = n/10;
		
		
		enemies = new Enemy[this.nenemies];
		for (int jj = 0; jj<x ; jj++)
			{
				for (int ii=0;ii<enemies.length;ii++) 
				{
					enemies[(jj*10)+ii] = new Enemy(5+10*ii,10+(10*jj),"enemy100.png",10+ii);
				}
		}
	}
	public void moveSwarm(int x, int y)
	{
		for (int i = 0 ; i < enemies.length ; i++)
		{
			enemies[i].setX(enemies[i].getX() - x);
			enemies[i].setY(enemies[i].getY() - y);
		}
	}
	
}
