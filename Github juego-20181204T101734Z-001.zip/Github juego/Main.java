package puch;
import java.util.Locale;

import edu.uc3m.game.GameBoardGUI;

public class Main {

	public static void main(String[] args) {
		Locale.setDefault(new Locale("en"));
		
		
		int idcounter = 1;
		
		GameBoardGUI game;
		game = new GameBoardGUI(17,22);
		game.setVisible(true);
		
		Player player1 = new Player();
		game.gb_addSprite(player1.getId(), player1.getImage(), true);
		game.gb_moveSpriteCoord(player1.getId(), player1.getX(), player1.getY());
		game.gb_setSpriteVisible(player1.getId(), true);
		
//		
//		Enemy enemy1[/*max enemies*/] = new Enemy[25];
//		for (int i = 0 ; i < enemy1.length ; i++)
//		{
//			enemy1[i] = new Enemy(20 + 10*i,110,"enemy100.png",1);
//			game.gb_addSprite(enemy1[i].getId(), enemy1[i].getImages(), true);
//			game.gb_moveSpriteCoord(enemy1[i].getId(), enemy1[i].getX(), enemy1[i].getY());
//			game.gb_setSpriteVisible(enemy1[i].getId(), true);
//		}
		Swarm s1 = new Swarm(10);
		
		for (int ii=0;ii<10;ii++)
		{
			game.gb_addSprite(s1.getEnemies()[ii].getId(), s1.getEnemies()[ii].getImages(), true);
			game.gb_moveSpriteCoord(s1.getEnemies()[ii].getId(), s1.getEnemies()[ii].getX(), s1.getEnemies()[ii].getY());
			game.gb_setSpriteVisible(s1.getEnemies()[ii].getId(), true);
			idcounter++;
		}
		
		

			
		
		

		
		
		
		Level level = new Level();
		
		game.gb_setValueLevel(level.getLevel());
		game.gb_setValueHealthMax(3);
		game.gb_setValueHealthCurrent(player1.getHealth());
		//game.gb_setTextPlayerName(player1.getname());
		game.gb_setTextPointsUp("Score:");
		game.gb_setValuePointsUp(player1.getPoints());
		game.gb_setTextPointsDown("Enemies remaining:");
		//game.gb_setValuePointsUp();
		game.gb_setGridColor(0, 0, 0);
		
		int pcount=1;
		Projectile[] p1 = new Projectile[0];
		
		
		do {
			String lastAction;
			lastAction = game.gb_getLastAction();
			if (lastAction.equals("right")) {
				player1.setX(player1.getX()+1);
			}
			
			if (lastAction.equals("left")) {
				int x = player1.getX();
				x--;
				player1.setX(x);
			}
			if(lastAction.equals("space"))
			{
				
				Projectile[] paux = new Projectile[pcount];
				
				for (int ii = 0;ii < p1.length;ii++) {
					paux[ii] = p1[ii];
				}
				
				p1 = new Projectile[pcount];
				
				for (int ii = 0;ii < p1.length;ii++) {
					p1[ii] = paux[ii];
					
				}
				
				p1[pcount - 1]= new Projectile(player1.getX(),player1.getY(),idcounter,true);
				idcounter++;
				
				
				for (int ii= 0;ii<p1.length;ii++) {
					game.gb_addSprite(p1[ii].getId(), p1[ii].getImage(), true);
					game.gb_moveSpriteCoord(p1[ii].getId(), p1[ii].getXpos(), p1[ii].getYpos());
					game.gb_setSpriteVisible(p1[ii].getId(), true);
					
				}
			}
			
			for (int ii);
			
			
			
			
			game.gb_moveSpriteCoord(player1.getId(), player1.getX(), player1.getY());
			
	

		}while (true);
		
		
	}

}
